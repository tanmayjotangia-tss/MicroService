package com.techlabs.employeeapp.service;

import com.techlabs.employeeapp.dto.EmployeeDto;
import com.techlabs.employeeapp.entity.Employee;
import com.techlabs.employeeapp.repository.EmployeeRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class EmployeeServiceImpl implements EmployeeService{

    private final EmployeeRepository employeeRepository;

    @Override
    public EmployeeDto getEmployee(Long employeeId) {
        Employee employee = employeeRepository.findById(employeeId)
                .orElseThrow(()-> new RuntimeException("ID not found: "+employeeId));

        EmployeeDto dto=new EmployeeDto();
        dto.setEmployeeId(employee.getEmployeeId());
        dto.setName(employee.getName());
        dto.setSalary(employee.getSalary());

        return dto;
    }
}
